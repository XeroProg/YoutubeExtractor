﻿namespace YoutubeExtractor
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.Download_btn = new System.Windows.Forms.Button();
            this.Details_btn = new System.Windows.Forms.Button();
            this.url_txt = new System.Windows.Forms.TextBox();
            this.visualStyler1 = new SkinSoft.VisualStyler.VisualStyler(this.components);
            this.pr1 = new System.Windows.Forms.ProgressBar();
            this.about_btn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.visualStyler1)).BeginInit();
            this.SuspendLayout();
            // 
            // Download_btn
            // 
            this.Download_btn.Location = new System.Drawing.Point(12, 38);
            this.Download_btn.Name = "Download_btn";
            this.Download_btn.Size = new System.Drawing.Size(96, 23);
            this.Download_btn.TabIndex = 0;
            this.Download_btn.Text = "Download";
            this.Download_btn.UseVisualStyleBackColor = true;
            this.Download_btn.Click += new System.EventHandler(this.Download_btn_Click);
            // 
            // Details_btn
            // 
            this.Details_btn.Location = new System.Drawing.Point(114, 38);
            this.Details_btn.Name = "Details_btn";
            this.Details_btn.Size = new System.Drawing.Size(103, 23);
            this.Details_btn.TabIndex = 1;
            this.Details_btn.Text = "Details";
            this.Details_btn.UseVisualStyleBackColor = true;
            this.Details_btn.Click += new System.EventHandler(this.Details_btn_Click);
            // 
            // url_txt
            // 
            this.url_txt.Location = new System.Drawing.Point(12, 12);
            this.url_txt.Name = "url_txt";
            this.url_txt.Size = new System.Drawing.Size(205, 20);
            this.url_txt.TabIndex = 2;
            // 
            // visualStyler1
            // 
            this.visualStyler1.HostForm = this;
            this.visualStyler1.License = ((SkinSoft.VisualStyler.Licensing.VisualStylerLicense)(resources.GetObject("visualStyler1.License")));
            this.visualStyler1.LoadVisualStyle(null, "Concave (Black).vssf");
            // 
            // pr1
            // 
            this.pr1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.pr1.Location = new System.Drawing.Point(12, 98);
            this.pr1.Name = "pr1";
            this.pr1.Size = new System.Drawing.Size(205, 23);
            this.pr1.TabIndex = 3;
            // 
            // about_btn
            // 
            this.about_btn.Location = new System.Drawing.Point(12, 67);
            this.about_btn.Name = "about_btn";
            this.about_btn.Size = new System.Drawing.Size(205, 23);
            this.about_btn.TabIndex = 4;
            this.about_btn.Text = "About Programmer";
            this.about_btn.UseVisualStyleBackColor = true;
            this.about_btn.Click += new System.EventHandler(this.About_btn_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(222, 128);
            this.Controls.Add(this.about_btn);
            this.Controls.Add(this.pr1);
            this.Controls.Add(this.url_txt);
            this.Controls.Add(this.Details_btn);
            this.Controls.Add(this.Download_btn);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Main";
            this.Text = "YoutubeExtractor";
            ((System.ComponentModel.ISupportInitialize)(this.visualStyler1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Download_btn;
        private System.Windows.Forms.Button Details_btn;
        private System.Windows.Forms.TextBox url_txt;
        private SkinSoft.VisualStyler.VisualStyler visualStyler1;
        private System.Windows.Forms.ProgressBar pr1;
        private System.Windows.Forms.Button about_btn;
    }
}

