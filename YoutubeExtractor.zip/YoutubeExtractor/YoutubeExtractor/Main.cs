﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using YoutubeExplode;
using YoutubeExplode.Models.MediaStreams;

namespace YoutubeExtractor
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }
        private async void  Download_btn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(url_txt.Text))
            { MessageBox.Show("Please Enter Video Link\r\nExample: https://www.youtube.com/watch?v=cdwal5Kw3Fc", "Empty Video Link",MessageBoxButtons.OK,MessageBoxIcon.Error); return; }
                var url = url_txt.Text;
                var id = YoutubeClient.ParseVideoId(url); // "bnsUkE8i0tU"
                var client = new YoutubeClient();
                // Get metadata for all streams in this video
                var streamInfoSet = await client.GetVideoMediaStreamInfosAsync(id);

                // Select one of the streams, e.g. highest quality muxed stream
                var streamInfo = streamInfoSet.Muxed.WithHighestVideoQuality();

                // ...or highest bitrate audio stream
                // var streamInfo = streamInfoSet.Audio.WithHighestBitrate();

                // ...or highest quality & highest framerate MP4 video stream
                // var streamInfo = streamInfoSet.Video
                //    .Where(s => s.Container == Container.Mp4)
                //    .OrderByDescending(s => s.VideoQuality)
                //    .ThenByDescending(s => s.Framerate)
                //    .First();

                // Get file extension based on stream's container
                var ext = streamInfo.Container.GetFileExtension();

                // Download stream to file
                pr1.Style = ProgressBarStyle.Marquee;
                await client.DownloadMediaStreamAsync(streamInfo, $"downloaded_video.{ext}");
                pr1.Style = ProgressBarStyle.Blocks;
                Details_btn_Click(sender, e);
        }

        private async void Details_btn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(url_txt.Text))
            { MessageBox.Show("Please Enter Video Link\r\nExample: https://www.youtube.com/watch?v=cdwal5Kw3Fc", "Empty Video Link", MessageBoxButtons.OK, MessageBoxIcon.Error); return; }
            var url = url_txt.Text;
            var id = YoutubeClient.ParseVideoId(url); // "bnsUkE8i0tU"
            var client = new YoutubeClient();
            var video = await client.GetVideoAsync(id);
            var title = video.Title; 
            var author = video.Author; 
            var duration = video.Duration;
            var Description = video.Description;
            var UploadDate = video.UploadDate;
            MessageBox.Show(string.Format("title: {0}\r\nauthor: {1}\r\nduration: {2}\r\ndescription: {3}\r\nuploadDate: {4}",title,author,duration,Description,UploadDate), "Details",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }

        private void About_btn_Click(object sender, EventArgs e)
        { MessageBox.Show("Programmer: XeroProg\r\nTelegram Username: @XeroProg\r\nGithub: https://github.com/XeroProg\r\nCompany: Novin7Soft","About Programmer",MessageBoxButtons.OK,MessageBoxIcon.Information); }
    }
}
